from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
# Create your views here.

#cors= cross origin request sharing
#csrf-cross site request forgery

# @csrf_exempt #for ignoring the security for this view
# def welcome(something):
#     # for prop in dir(something):
#     #    print(prop)
#     return HttpResponse("welcome page")

details=[{
    "id_":1,
    "name":"Harshi",
    "profession":"software dev",
    "salary":6000000

},
{
     "id_":2,
    "name":"monisha",
    "profession":"python dev",
    "salary":8000000
}
]



@csrf_exempt
def welcome(request):
    if(request.method)=="GET":
        return HttpResponse("welcome to get request")
    else:
        return HttpResponse("invalid method")
    
def details_view(req):
    return JsonResponse({"response":details})
# query params
#url/search?amazon
#url/user?harshi&&passwd??123

# url params
# product/1
# user/10
# samsung/brand


# def single_user(req,id):
#     return JsonResponse({"user":id})

def single_user(req,id):
    for user in details:
        if id==user["id_"]:
            return JsonResponse({"user_data":user})
    return JsonResponse({"msg":"user does not exist"})

#json.dumps-> when sending
#json.load-> when recievng
@csrf_exempt
def register_user(req):
    user_data=json.loads(req.body)
    print(user_data)
    if user_data not in details:
       details.append(user_data) #to add the user data to details
    else:
        return HttpResponse("user already exists")
    print(details)
    return HttpResponse("registeration success")



    