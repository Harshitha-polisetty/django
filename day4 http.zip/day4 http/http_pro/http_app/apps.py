from django.apps import AppConfig


class HttpAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'http_app'
